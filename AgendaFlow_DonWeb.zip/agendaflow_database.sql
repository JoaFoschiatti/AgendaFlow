-- ============================================================================
-- AgendaFlow Database Schema - Production Ready v2.0
-- ============================================================================
-- Generated: 2024-09-19
-- Version: 2.0.0 CLEAN
-- Description: Complete database schema for AgendaFlow - No demo data
-- ============================================================================

SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET time_zone = '+00:00';
SET NAMES utf8mb4 COLLATE utf8mb4_spanish2_ci;
SET collation_connection = 'utf8mb4_spanish2_ci';

-- ============================================================================
-- CLEAN INSTALLATION - DROP AND RECREATE DATABASE
-- ============================================================================

DROP DATABASE IF EXISTS agendaflow;
CREATE DATABASE agendaflow CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish2_ci;
USE agendaflow;

-- ============================================================================
-- TABLE: users
-- ============================================================================

CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    business_name VARCHAR(150) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    timezone VARCHAR(50) DEFAULT 'America/Argentina/Buenos_Aires',
    currency VARCHAR(3) DEFAULT 'ARS',
    subscription_status ENUM('trialing', 'active', 'past_due', 'canceled', 'paused') DEFAULT 'trialing',
    subscription_plan VARCHAR(50),
    trial_starts_at DATETIME,
    trial_ends_at DATETIME,
    mp_customer_id VARCHAR(100),
    mp_subscription_id VARCHAR(100),
    mp_preapproval_id VARCHAR(100),
    last_payment_date DATETIME,
    last_payment_amount DECIMAL(10,2),
    last_payment_id VARCHAR(100),
    next_billing_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_subscription_status (subscription_status),
    INDEX idx_trial_ends (trial_ends_at),
    INDEX idx_next_billing (next_billing_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

-- ============================================================================
-- TABLE: services
-- ============================================================================

CREATE TABLE services (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price_default DECIMAL(12,2) DEFAULT 0.00,
    duration_min INT UNSIGNED,
    color VARCHAR(7),
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_user_name (user_id, name),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

-- ============================================================================
-- TABLE: clients
-- ============================================================================

CREATE TABLE clients (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    address VARCHAR(255),
    notes TEXT,
    birth_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_user_name (user_id, name),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

-- ============================================================================
-- TABLE: appointments
-- ============================================================================

CREATE TABLE appointments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    client_id INT UNSIGNED,
    client_name VARCHAR(100) NOT NULL,
    client_phone VARCHAR(20),
    service_id INT UNSIGNED,
    appointment_date DATE NOT NULL,
    starts_at DATETIME NOT NULL,
    ends_at DATETIME NOT NULL,
    price DECIMAL(12,2) DEFAULT 0.00,
    status ENUM('scheduled', 'confirmed', 'completed', 'canceled', 'no_show') DEFAULT 'scheduled',
    notes TEXT,
    reminder_sent TINYINT(1) DEFAULT 0,
    canceled_at DATETIME,
    canceled_reason VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_client_id (client_id),
    INDEX idx_service_id (service_id),
    INDEX idx_date (appointment_date),
    INDEX idx_starts_at (starts_at),
    INDEX idx_status (status),
    INDEX idx_user_date (user_id, appointment_date),
    INDEX idx_user_status (user_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

-- ============================================================================
-- TABLE: subscriptions
-- ============================================================================

CREATE TABLE subscriptions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    plan_id VARCHAR(50) NOT NULL,
    status ENUM('pending', 'authorized', 'paused', 'cancelled') NOT NULL,
    mp_preapproval_id VARCHAR(100) UNIQUE,
    mp_preapproval_plan_id VARCHAR(100),
    mp_payer_id VARCHAR(100),
    mp_payer_email VARCHAR(150),
    mp_card_id VARCHAR(100),
    mp_payment_method_id VARCHAR(50),
    mp_status VARCHAR(50),
    mp_status_detail VARCHAR(100),
    reason VARCHAR(255),
    external_reference VARCHAR(100),
    date_created DATETIME,
    last_modified DATETIME,
    init_point VARCHAR(500),
    sandbox_init_point VARCHAR(500),
    auto_recurring JSON,
    summarized JSON,
    next_payment_date DATE,
    subscription_start DATETIME,
    subscription_end DATETIME,
    first_invoice_offset INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_mp_preapproval_id (mp_preapproval_id),
    INDEX idx_status (status),
    INDEX idx_next_payment_date (next_payment_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

-- ============================================================================
-- TABLE: payments
-- ============================================================================

CREATE TABLE payments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    mp_payment_id VARCHAR(100) UNIQUE,
    mp_preapproval_id VARCHAR(100),
    payment_type VARCHAR(50),
    payment_method_id VARCHAR(50),
    status VARCHAR(50) NOT NULL,
    status_detail VARCHAR(100),
    currency_id VARCHAR(3),
    amount DECIMAL(12,2) NOT NULL,
    transaction_amount DECIMAL(12,2),
    fee_amount DECIMAL(12,2),
    net_amount DECIMAL(12,2),
    date_created DATETIME,
    date_approved DATETIME,
    date_last_updated DATETIME,
    money_release_date DATETIME,
    payer_email VARCHAR(150),
    payer_id VARCHAR(100),
    payer_type VARCHAR(50),
    description TEXT,
    statement_descriptor VARCHAR(100),
    notification_url VARCHAR(500),
    callback_url VARCHAR(500),
    external_reference VARCHAR(100),
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_mp_payment_id (mp_payment_id),
    INDEX idx_mp_preapproval_id (mp_preapproval_id),
    INDEX idx_status (status),
    INDEX idx_date_created (date_created)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

-- ============================================================================
-- TABLE: settings
-- ============================================================================

CREATE TABLE settings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    day_of_week TINYINT NOT NULL COMMENT '0=Sunday, 6=Saturday',
    open_time TIME,
    close_time TIME,
    slot_minutes INT DEFAULT 15,
    allow_overlaps TINYINT(1) DEFAULT 0,
    closed TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_day (user_id, day_of_week),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- TABLE: audit_logs
-- ============================================================================

CREATE TABLE audit_logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED,
    action VARCHAR(50) NOT NULL,
    entity VARCHAR(50),
    entity_id INT UNSIGNED,
    data JSON,
    ip_address VARCHAR(45),
    user_agent VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_action (action),
    INDEX idx_entity (entity, entity_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- FINAL NOTES
-- ============================================================================
-- This database is ready for production use
-- No demo data is included - all users start with empty accounts
-- All column names are consistent with the PHP code (is_active, not active)
-- All tables use InnoDB for transaction support
-- All foreign keys are properly defined
-- All necessary indexes are created for optimal performance
-- ============================================================================
